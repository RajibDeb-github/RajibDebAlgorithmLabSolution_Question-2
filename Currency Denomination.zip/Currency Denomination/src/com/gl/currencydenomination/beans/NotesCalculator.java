package com.gl.currencydenomination.beans;

import java.util.Scanner;

public class NotesCalculator {
	public static int i, j;

	public void paymentApproach(int[] arr) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the amount you want to pay");
		int amount = sc.nextInt();
		// int totalSum=0;
		int div = 0, rem = amount, tmp = 0;
		if (amount > 0) { // if1
			for (i = 0; i < arr.length; i++) { // for 1
				if (rem >= arr[i]) { // if2
					div = rem / arr[i];
					div = tmp + div;

					rem = rem % arr[i];
					System.out.println(
							"Your payment approach in order to give min no of notes will be " + arr[i] + ": " + div);       //Printing the output
					
				} // if2

			} // for1

		} // if1
		else {
			System.out.println("Please enter the pay amount greater than 0");
		}

	}
}
