package com.gl.currencydenomination.main;

import java.util.Scanner;

import com.gl.currencydenomination.beans.NotesCalculator;
import com.gl.currencydenomination.services.Array;

public class Driver {
	public static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Enter the size of currency denominations");
		int sizeArr = sc.nextInt(); // Declaring the array size
		int[] arr = new int[sizeArr]; // Initiate an array space in memory
		Array array = new Array(); // Instance of array class
		array.createArray(arr); // Calling createArray function
		// array.traverseArray(arr); // Calling traverse function
		array.bubbleSort(arr); // Sorting the array by bubble sort
		// array.traverseArray(arr);
		NotesCalculator nc = new NotesCalculator();
		nc.paymentApproach(arr);

	}

}
